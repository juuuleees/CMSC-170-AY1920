public class Main {
	public static void main(String args[]) {
		Game main_game = new Game();
		main_game.run();
		// TODO: run()?
	}
}