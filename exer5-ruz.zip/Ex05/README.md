RUZ, Julianne Marie
2014-04280
CMSC 170 U-1L

Exercise 5: Spam Filtering Using a Naive Bayes Classifier and Augmenting with Laplace Smoothing

Github link: https://github.com/juuuleees/CMSC-170-AY1920

Notes:

	> probability values slowly approach zero during computation. Adjusting the number of decimal places hasn't made it better as of 1654H.