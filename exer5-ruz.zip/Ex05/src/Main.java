public class Main {
	public static void main (String args[]) {
		Program bag_of_words = new Program();

		bag_of_words.run();
	} 
}